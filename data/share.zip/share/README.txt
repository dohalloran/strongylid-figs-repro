Contents:
- tables/: genus/species aggregated Bracken TSVs (r=120)
- kreports/: Kraken2 reports (and _bracken.kreport if present)
- db/: DB inspect 
- meta/: srr_manifest.txt mapping SRR -> host/site/…
